// proxy-chain/chrome-extension/background.js

const NODE_APP_CONTROL_URL_BASE = 'http://127.0.0.1:9998';
const LOCAL_PROXY_ADDRESS = '127.0.0.1:9999';

// --- Utility Functions ---
// Helper function for safer storage operations
async function safeSyncStorage(operation, data = null, defaultValue = null) {
  try {
    return await new Promise((resolve, reject) => {
      if (operation === 'get' && data) {
        chrome.storage.sync.get(data, (result) => {
          if (chrome.runtime.lastError) {
            console.error(`Error getting ${JSON.stringify(data)} from sync storage:`, chrome.runtime.lastError);
            reject(chrome.runtime.lastError);
          } else {
            resolve(result);
          }
        });
      } else if (operation === 'set' && data) {
        chrome.storage.sync.set(data, () => {
          if (chrome.runtime.lastError) {
            console.error(`Error saving to sync storage:`, chrome.runtime.lastError);
            reject(chrome.runtime.lastError);
          } else {
            resolve(true);
          }
        });
      } else {
        reject(new Error(`Invalid storage operation: ${operation}`));
      }
    });
  } catch (error) {
    console.warn(`Storage operation failed (${operation}):`, error);
    return defaultValue;
  }
}

// --- Node.js App Communication ---
async function sendCommandToNodeApp(endpoint, method = 'GET', body = null) {
  try {
    const response = await fetch(`${NODE_APP_CONTROL_URL_BASE}${endpoint}`,
      {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: body ? JSON.stringify(body) : null,
      }
    );
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: response.statusText }));
      console.error(`Error from Node.js app (${endpoint}): ${response.status}`, errorData);
      throw new Error(`Node.js app error: ${errorData.message || response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Failed to communicate with Node.js app (${endpoint}):`, error);
    throw error;
  }
}

async function getNodeAppStatus() {
  try {
    const status = await sendCommandToNodeApp('/status');
    return { success: true, ...status };
  } catch (error) {
    return { success: false, running: false, message: error.message };
  }
}

async function configureNodeAppProxy(upstreamProxyUrl) {
  try {
    await sendCommandToNodeApp('/config', 'POST', { upstreamProxyUrl });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

async function stopNodeAppProxy() {
  try {
    await sendCommandToNodeApp('/stop', 'POST');
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

// --- Chrome Proxy Settings ---
async function getStoredBypassList() {
  const defaultList = ["localhost", "127.0.0.1", "<local>"];
  const result = await safeSyncStorage('get', { bypassList: defaultList }, { bypassList: defaultList });
  
  // Ensure default localhost/127.0.0.1/<local> are there if list is empty or not well-formed
  let list = Array.isArray(result.bypassList) ? result.bypassList : [];
  if (!list.includes("localhost")) list.unshift("localhost");
  if (!list.includes("127.0.0.1")) list.unshift("127.0.0.1");
  if (!list.includes("<local>")) list.unshift("<local>");
  
  // Remove duplicates that might have been added if they existed before unshift
  return [...new Set(list)];
}

// Update the formatBypassEntry function to better handle domains
function formatBypassEntry(entry) {
  entry = entry.trim().toLowerCase();
  if (!entry) return null;

  try {
    // If it's already a pattern like *.example.com or <local> or an IP, keep it
    if (entry === '<local>' || /^\d{1,3}(\.\d{1,3}){3}(?:\/\d{1,2})?$/.test(entry)) {
      return entry;
    }
    
    // Add a scheme if missing, for URL constructor to work reliably
    let urlToParse = entry;
    if (!urlToParse.includes('://')) {
      urlToParse = 'http://' + urlToParse; 
    }
    const url = new URL(urlToParse);
    let hostname = url.hostname;
    
    // Always remove www. prefix if present
    hostname = hostname.replace(/^www\./, '');
    
    // If it's not already a wildcard pattern, make it one
    if (!hostname.startsWith('*.')) {
      hostname = '*.' + hostname;
    }
    
    return hostname;
  } catch (e) {
    // If parsing fails, try to handle it as a simple hostname
    entry = entry.replace(/^www\./, ''); // Remove www. if present
    if (entry.includes('/') || entry.includes(':') || entry.includes('?')){
      console.warn(`Bypass entry "${entry}" could not be parsed as URL and seems complex, not auto-formatting.`);
      return entry;
    }
    // Add wildcard for subdomains if not present
    if (!entry.startsWith('*.')) {
      entry = '*.' + entry;
    }
    return entry;
  }
}

// Update the isUrlInBypassList function to better handle paths and subdomains
function isUrlInBypassList(url, bypassList) {
  if (!url || !bypassList) return false;
  
  try {
    const urlObj = new URL(url);
    let hostname = urlObj.hostname;
    
    // Remove www. from the hostname for comparison
    hostname = hostname.replace(/^www\./, '');
    
    // Debug log to trace bypass checks
    console.log(`Checking if ${hostname} is in bypass list...`);
    
    for (const pattern of bypassList) {
      // For <local> patterns
      if (pattern === '<local>') {
        if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname.includes('.local')) {
          console.log(`✓ ${hostname} matches <local> pattern`);
          return true;
        }
        continue;
      }
      
      // For IP addresses
      if (/^\d{1,3}(\.\d{1,3}){3}(?:\/\d{1,2})?$/.test(pattern)) {
        if (hostname === pattern) {
          console.log(`✓ ${hostname} matches IP pattern ${pattern}`);
          return true;
        }
        continue;
      }
      
      // For domain patterns - strip any wildcards for comparison
      const domainPattern = pattern.replace(/^\*\./, '');
      
      // Check for exact match
      if (hostname === domainPattern) {
        console.log(`✓ ${hostname} exact match with ${pattern}`);
        return true;
      }
      
      // Check if hostname is a subdomain of pattern (e.g., assets.twitch.tv matches twitch.tv)
      if (hostname.endsWith('.' + domainPattern)) {
        console.log(`✓ ${hostname} is subdomain of ${pattern}`);
        return true;
      }
    }
    
    console.log(`✗ ${hostname} NOT found in bypass list`);
    return false;
  } catch (e) {
    console.error('Error checking URL against bypass list:', e);
    return false;
  }
}

async function setChromeProxy(proxyUrl) {
  const userBypassList = await getStoredBypassList();
  console.log("Using bypass list:", userBypassList);

  // Parse the proxy URL
  const [host, portStr] = proxyUrl.split(':');
  const port = parseInt(portStr, 10);

  if (!host || isNaN(port)) {
    console.error(`Invalid proxy URL format: ${proxyUrl}`);
    return;
  }

  // Format the bypass list patterns for Chrome's proxy API
  // Chrome's proxy API uses a different format than our internal bypass list
  const formattedBypassList = userBypassList.map(pattern => {
    // Keep <local> as is (Chrome understands this)
    if (pattern === '<local>') {
      return pattern;
    }
    
    // For IP addresses with CIDR notation, keep as is
    if (/^\d{1,3}(\.\d{1,3}){3}(\/\d{1,2})?$/.test(pattern)) {
      return pattern;
    }
    
    // Remove any * prefix if present
    pattern = pattern.replace(/^\*\./, '');
    
    // Add the required * prefix for Chrome's proxy API to match all subdomains
    // This ensures that subdomains like assets.twitch.tv will be bypassed if twitch.tv is in the list
    return `*${pattern.startsWith('.') ? '' : '.'}${pattern}`;
  });

  console.log("Formatted bypass list for Chrome:", formattedBypassList);

  // No need to expand the bypass list anymore since we're using wildcards
  const config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http", // The local proxy server is HTTP
        host: host,
        port: port,
      },
      bypassList: formattedBypassList
    }
  };
  
  try {
    await new Promise((resolve, reject) => {
      chrome.proxy.settings.set({ value: config, scope: 'regular' }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error setting Chrome proxy:', chrome.runtime.lastError);
          reject(chrome.runtime.lastError);
        } else {
          console.log(`Chrome proxy set to: ${proxyUrl}`);
          resolve();
        }
      });
    });
    updateBadgeForCurrentTab();
  } catch (error) {
    console.error('Failed to set Chrome proxy:', error);
    throw error;
  }
}

// Add new function to update badge based on current tab
async function updateBadgeForCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;

    const data = await safeSyncStorage(
      'get',
      ['currentProxyStatus', 'bypassList', 'siteSpecificMode', 'siteSpecificDomain'],
      { currentProxyStatus: 'disconnected', bypassList: [], siteSpecificMode: false, siteSpecificDomain: null }
    );

    if (data.currentProxyStatus === 'connected') {
      // Site-specific mode handling
      if (data.siteSpecificMode && data.siteSpecificDomain) {
        const url = new URL(tab.url);
        const hostname = url.hostname.replace(/^www\./, '');
        
        // Check if the current tab's domain matches the site-specific domain
        if (hostname === data.siteSpecificDomain || hostname.endsWith('.' + data.siteSpecificDomain)) {
          chrome.action.setBadgeText({ text: 'SITE' });
          chrome.action.setBadgeBackgroundColor({ color: '#6610f2' }); // Purple to match the site-action button
        } else {
          chrome.action.setBadgeText({ text: 'OFF' });
          chrome.action.setBadgeBackgroundColor({ color: '#6c757d' }); // Gray for sites not being proxied
        }
      } 
      // Standard proxy mode with bypass list
      else if (isUrlInBypassList(tab.url, data.bypassList)) {
        chrome.action.setBadgeText({ text: 'BYPASS' });
        chrome.action.setBadgeBackgroundColor({ color: '#FFA500' });
      } else {
        chrome.action.setBadgeText({ text: 'ON' });
        chrome.action.setBadgeBackgroundColor({ color: [76, 175, 80, 255] });
      }
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {
    console.error('Error updating badge:', e);
  }
}

// Add tab change listeners
chrome.tabs.onActivated.addListener(() => {
  updateBadgeForCurrentTab();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id === tabId) {
        updateBadgeForCurrentTab();
      }
    });
  }
});

// Update clearChromeProxy to use updateBadgeForCurrentTab
async function clearChromeProxy() {
  try {
    await new Promise((resolve, reject) => {
      chrome.proxy.settings.clear({ scope: 'regular' }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error clearing Chrome proxy:', chrome.runtime.lastError);
          reject(chrome.runtime.lastError);
        } else {
          console.log('Chrome proxy cleared (using system settings).');
          resolve();
        }
      });
    });
    updateBadgeForCurrentTab();
  } catch (error) {
    console.error('Failed to clear Chrome proxy:', error);
    throw error;
  }
}

// --- Message Handling from Popup ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    if (request.action === "getNodeAppStatus") {
      const status = await getNodeAppStatus();
      sendResponse(status);
    } else if (request.action === "connectProxy") {
      const { upstreamProxyUrl, siteSpecific, targetDomain } = request.data;
      if (!upstreamProxyUrl) {
        sendResponse({ success: false, message: 'Upstream proxy URL is required.' });
        return;
      }
      
      console.log("Connect proxy request:", request.data);
      
      // Node app configuration happens first
      const nodeAppConfigResult = await configureNodeAppProxy(upstreamProxyUrl);
      if (nodeAppConfigResult.success) {
        try {
          // If Node app is configured, then set Chrome's proxy settings
          if (siteSpecific && targetDomain) {
            // For site-specific proxy, we use a PAC script
            const pacScript = `function FindProxyForURL(url, host) {
              // Convert hostname to lowercase
              host = host.toLowerCase();
              
              // Remove any www. prefix
              host = host.replace(/^www\\./, '');
              
              // Check if the host matches the target domain or is a subdomain
              if (host === "${targetDomain}" || host.endsWith(".${targetDomain}")) {
                return "PROXY ${LOCAL_PROXY_ADDRESS}";
              }
              
              // For all other hosts, use direct connection
              return "DIRECT";
            }`;
            
            console.log("Using PAC script for site-specific proxy:", pacScript);
            
            // Use PAC script configuration
            const config = {
              mode: "pac_script",
              pacScript: {
                data: pacScript
              }
            };
            
            await new Promise((resolve, reject) => {
              chrome.proxy.settings.set({ value: config, scope: 'regular' }, () => {
                if (chrome.runtime.lastError) {
                  console.error('Error setting Chrome proxy with PAC script:', chrome.runtime.lastError);
                  reject(chrome.runtime.lastError);
                } else {
                  console.log(`Chrome proxy set with PAC script for ${targetDomain} only`);
                  resolve();
                }
              });
            });
          } else {
            // Standard proxy configuration using the local proxy address
            await setChromeProxy(LOCAL_PROXY_ADDRESS);
          }
          
          let statusMessage = 'Proxy connected and Chrome settings applied.';
          if (siteSpecific && targetDomain) {
            statusMessage = `Proxy connected for ${targetDomain} only.`;
          }
          
          // Save connection status to sync storage
          await safeSyncStorage('set', { 
            currentProxyStatus: 'connected', 
            currentUpstream: upstreamProxyUrl,
            siteSpecificMode: siteSpecific ? true : false,
            siteSpecificDomain: siteSpecific ? targetDomain : null
          }, null);
          
          updateBadgeForCurrentTab();
          sendResponse({ success: true, message: statusMessage });
        } catch (error) {
          console.error('Error setting Chrome proxy:', error);
          sendResponse({ success: false, message: `Failed to configure Chrome proxy: ${error.message}` });
        }
      } else {
        sendResponse({ success: false, message: `Failed to configure Node.js app: ${nodeAppConfigResult.message}` });
      }
    } else if (request.action === "disconnectProxy") {
      try {
        await clearChromeProxy();
        // Optionally stop the Node.js proxy server or leave it running but unused.
        // For now, we'll just clear Chrome's settings and update status.
        await stopNodeAppProxy(); // Uncomment if Node.js proxy should be stopped.
        
        // Save disconnected status to sync storage
        await safeSyncStorage('set', { 
          currentProxyStatus: 'disconnected', 
          currentUpstream: null 
        }, null);
        
        sendResponse({ success: true, message: 'Proxy disconnected.' });
      } catch (error) {
        console.error('Error disconnecting proxy:', error);
        sendResponse({ success: false, message: `Failed to disconnect proxy: ${error.message}` });
      }
    } else if (request.action === "getChromeProxyStatus") {
        chrome.proxy.settings.get({incognito: false}, (config) => {
            if (chrome.runtime.lastError) {
                sendResponse({ status: 'error', message: chrome.runtime.lastError.message });
                return;
            }
            let statusText = 'System Settings';
            if (config.value.mode === 'fixed_servers' && 
                config.value.rules && 
                config.value.rules.singleProxy &&
                `${config.value.rules.singleProxy.host}:${config.value.rules.singleProxy.port}` === LOCAL_PROXY_ADDRESS) {
                statusText = `Active (${LOCAL_PROXY_ADDRESS})`;
            } else if (config.value.mode !== 'system') {
                statusText = `Other (${config.value.mode})`;
            }
            sendResponse({ status: 'success', proxyStatus: statusText, config: config.value });
        });
    }
  })();
  return true; // Indicates that the response is sent asynchronously
});

// --- Initial State & Alarms (Example for periodic status check) ---
chrome.runtime.onStartup.addListener(async () => {
  console.log("Extension started up.");
  // Check status or perform other startup tasks
  try {
    const data = await safeSyncStorage(
      'get', 
      ['currentProxyStatus', 'currentUpstream'], 
      { currentProxyStatus: 'disconnected', currentUpstream: null }
    );
    
    if (data.currentProxyStatus === 'connected' && data.currentUpstream) {
      console.log('Attempting to restore proxy connection on startup.');
      // Potentially re-verify Node app and Chrome proxy settings
      // Re-apply Chrome proxy settings to ensure bypass list is current if it changed while extension was off
      await setChromeProxy(LOCAL_PROXY_ADDRESS); // This will use the latest bypass list
      // Set badge if was connected (already done by setChromeProxy)
    } else {
      // Ensure proxy is cleared if not supposed to be connected
      clearChromeProxy(); 
      await safeSyncStorage(
        'set', 
        { currentProxyStatus: 'disconnected', currentUpstream: null }, 
        null
      );
      // Badge clearing is handled by clearChromeProxy
    }
  } catch (error) {
    console.error('Error during startup processing:', error);
    // Failsafe: clear proxy settings on error
    clearChromeProxy();
  }
});

chrome.alarms.create('checkNodeAppStatus', { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'checkNodeAppStatus') {
    const status = await getNodeAppStatus();
    // console.log('Periodic Node.js App Status:', status);
    // Optionally update UI or take action based on status
    // This is tricky to communicate back to popup if not open.
    // Notifications could be used for critical status changes.
    if (!status.success || !status.running) {
        // If node app is not running but chrome is configured to use it, show notification
        chrome.storage.sync.get(['currentProxyStatus'], (data) => {
            if (data.currentProxyStatus === 'connected') {
                 chrome.notifications.create('nodeAppDown', {
                    type: 'basic',
                    iconUrl: 'images/icon128.png',
                    title: 'Proxy Manager Alert',
                    message: 'The Node.js proxy helper app appears to be down. Proxying may not work.'
                });
            }
        });
    }
  }
});

console.log("Background service worker started."); 